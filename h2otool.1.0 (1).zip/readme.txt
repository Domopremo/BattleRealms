H2OTool - H2O archive extraction utility
hosted at http://sourceforge.net/projects/h2otool